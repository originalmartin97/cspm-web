**Gazdasági és pénzügyi szakembereknek\!\!\!**

**"Készen állsz a következő lépésre a karrieredben?**  
Ha pénzügyi vagy gazdasági háttérrel rendelkezel, és vonz a vállalkozói szabadság és felelősség, nálunk a helyed\! Csatlakozz csapatunkhoz, ahol önállóan dolgozhatsz, és kiteljesedhetsz szakmai területen\!

📌 Rugalmas munkaidő  
📌 Vállalkozói szemlélet támogatása  
📌 Képzések és mentorálás

💼 Érdekel? Vedd fel velünk a kapcsolatot még ma\!"

[Kattintson ide\!](https://docs.google.com/forms/d/e/1FAIpQLSdOTh1p6X8CBc9CtQE4Bh5COleWSxZentfxq6RlGbA_Wyuibw/viewform?usp=header)

